	1-Some eclipse projects are required in order to run properly the ATL transformations:
		* GMF
		* UML2 
		* UML2 Tools
	2-External library is required : http://ant-contrib.sourceforge.net/
