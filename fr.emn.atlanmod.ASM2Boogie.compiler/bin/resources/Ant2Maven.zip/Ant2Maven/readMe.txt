Ant2Maven :
	import XML Model
	run XML2Ant.atl
	run Ant2Maven.atl
	run Maven2XML.atl
	run XML2Text.atl for the two files (maven.xml and project.xml)

files in directory 'example':
 build.xml is the XML-based file in Ant;
 build.xmi is the Model imported from build.xml (corresponds to the XML Metamodel);
 buildAnt.xmi is the file obtained after running XML2Ant.atl (corresponds to the Ant Metamodel);
 projectFile.xmi and mavenFile.xmi are the files obtained after running Ant2Maven.atl
	(projectFile.xmi corresponds to the MavenProject Metamodel,
	 mavenFile.xmi corresponds to the MavenMaven Metamodel);
 projectFileXML.xmi and mavenFileXML.xmi are the files obtained after running Maven2XML.atl
	(these two files corresponds to the XML Metamodel);
 project.xml is the file obtained after running XML2Text.atl
	(after having changed the third line: "writeTo('myDirectory\\project.xml')");
 maven.xml is the file obtained after running XML2Text.atl
	(after having changed the third line: "writeTo('myDirectory\\maven.xml')");