The "QVT Compiler and Launcher.xml" ant script compiles Book2Publication.ecore
(i.e., the model corresponding to Book2Publication.qvt) into Book2Publication.asm,
and then run it on the My.books model to generate the My.pub model.
