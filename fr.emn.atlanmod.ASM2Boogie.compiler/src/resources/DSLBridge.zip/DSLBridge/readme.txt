Metamodel files
---------------
 * XML.ecore, XML.km3
 * DSL.ecore, DSL.km3
 * DSLModel.ecore, DSLModel.km3
 * KM3.ecore, KM3.km3
 * KM2.ecore, KM2.km3
 * ATL-0.2.ecore, ATL-0.2.ecore

The metamodel files are stored in the folder "MetaModels/".
Km3 files provide readable versions of these metamodels in the km3 format.

Files (transformations and example files) related to Metamodel Bridge and the Model Bridge are respectively stored in the "MetamodelBridge/" and the "ModelBridge/" folders, with dedicated readme files.