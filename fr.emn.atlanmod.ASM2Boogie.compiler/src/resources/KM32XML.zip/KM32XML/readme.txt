Metamodel file
---------------
 * XML.ecore

Example files
-------------
 * JavaAbstractSyntax.km3: KM3 sample file
 * JavaAbstractSyntax.xml: XML file created from the sample KM3 file

Transformation files
--------------------
 * KM32XML.atl
 * LibFAQL.atl

The KM32XML transformation ("KM32XML.atl") can be tested with the KM3 file ("JavaAbstractSyntax.km3") as input.
It returns an XML file ("JavaAbstractSyntax.xml").

Launch Configuration
--------------------
build.xml: Ant Script to execute this scenario